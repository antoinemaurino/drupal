<?php
/**
  * @file
  * filelisting_loading_moredata.tpl.php
  */
?>  

<div class="loading" style="background-color:#FAFAFA;padding-left:<?php print $message_padding ?> px; "><span style="padding-right:10px;">Standby loading more records ....</span><span style="color:#000">[&nbsp;<a href="?cid=<?php print $cid?>&fid=<?php print $fid ?>&fnum=<?php print $foldernumber ?>&level=<?php print $level ?>&pass2=1" class="morefolderdata">Click here if files do not appear</a>&nbsp;]</span>
</div>