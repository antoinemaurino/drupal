<?php
/**
  * @file
  * native_filelisting_header.tpl.php
  */
?>  

<p><strong><?php print t('Files') ?></strong></p>
