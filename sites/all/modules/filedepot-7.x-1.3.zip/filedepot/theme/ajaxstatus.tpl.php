<?php
/**
  * @file
  * ajaxstatus.tpl.php
  */
?>

<div id="filedepot_ajaxStatus" class="floatright pluginAjaxStatus" style="padding-right:20px;margin-bottom:5px;visibility:hidden;"></div>