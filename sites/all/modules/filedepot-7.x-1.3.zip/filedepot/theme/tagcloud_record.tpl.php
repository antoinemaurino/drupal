<?php
/**
  * @file
  * tagcloud_record.tpl.php
  */
?>  

<span style="font-size:<?php print $fontsize ?>%"><a class="tagcloudword" href="#"><?php print $tag ?></a></span>
