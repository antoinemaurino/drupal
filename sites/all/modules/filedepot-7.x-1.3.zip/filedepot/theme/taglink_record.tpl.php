<?php
/**
  * @file
  * taglink_record.tpl.php
  */
?>  

<div class="listing_searchtag"><a href="#" onClick="makeAJAXSearchTags('<?php print $searchtag ?>');return false;"><?php print $label ?></a></div>
